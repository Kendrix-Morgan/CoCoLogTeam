//
//  Recommendation.swift
//  HeartEase
//
//  Created by YUN NADI OO   on 2025/07/22.
//

import SwiftUI

struct Recommendation: View {
    var body: some View {
        GeometryReader{ geometry in
            VStack{
                
            }.frame(width: geometry.size.width, height: geometry.size.height)
                .background(Color(red: 250/255, green: 246/255, blue: 235/255))
            
        }
    }
}

#Preview {
    Recommendation()
}
