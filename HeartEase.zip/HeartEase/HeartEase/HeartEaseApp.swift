//
//  HeartEaseApp.swift
//  HeartEase
//
//  Created by YUN NADI OO on 2025/07/18.
//

import SwiftUI

@main
struct HeartEaseApp: App {
    init() {
        // 💅 TabBar appearance (already done)
        let tabAppearance = UITabBarAppearance()
        tabAppearance.configureWithOpaqueBackground()
        tabAppearance.backgroundColor = UIColor(red: 250/255, green: 246/255, blue: 235/255, alpha: 1.0)
        tabAppearance.stackedLayoutAppearance.selected.iconColor = UIColor(red: 84/255, green: 54/255, blue: 47/255, alpha: 1.0)
        tabAppearance.stackedLayoutAppearance.selected.titleTextAttributes = [.foregroundColor: UIColor(red: 84/255, green: 54/255, blue: 47/255, alpha: 1.0)]
        tabAppearance.stackedLayoutAppearance.normal.iconColor = UIColor(red: 180/255, green: 160/255, blue: 150/255, alpha: 1.0)
        tabAppearance.stackedLayoutAppearance.normal.titleTextAttributes = [.foregroundColor: UIColor(red: 180/255, green: 160/255, blue: 150/255, alpha: 1.0)]
        UITabBar.appearance().standardAppearance = tabAppearance

        // ✨ NavigationBar title color
        let navAppearance = UINavigationBarAppearance()
        navAppearance.configureWithOpaqueBackground()
        navAppearance.backgroundColor = UIColor(red: 250/255, green: 246/255, blue: 235/255, alpha: 1.0)
        navAppearance.titleTextAttributes = [.foregroundColor: UIColor(red: 84/255, green: 54/255, blue: 47/255, alpha: 1.0)]
        navAppearance.largeTitleTextAttributes = [.foregroundColor: UIColor(red: 84/255, green: 54/255, blue: 47/255, alpha: 1.0)]

        UINavigationBar.appearance().standardAppearance = navAppearance
        UINavigationBar.appearance().scrollEdgeAppearance = navAppearance
    }

    @StateObject var historyModel = HistoryModel()
    @StateObject var bleManager = BLEManager()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(historyModel)
                .environmentObject(bleManager)
        }
    }
}
