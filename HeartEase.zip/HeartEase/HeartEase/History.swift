//  HistoryView.swift
//  HeartEase / CocoLog

import SwiftUI

struct MeasurementEntry: Identifiable, Codable {
    var id = UUID()
    let date: Date
    let bpm: Int
    let hrv: Float
    let spo2: Int
}

class HistoryModel: ObservableObject {
    @Published var entries: [MeasurementEntry] = [] {
        didSet {
            save()
        }
    }

    init() {
        load()
    }

    func addEntry(bpm: Int, hrv: Float, spo2: Int) {
        let newEntry = MeasurementEntry(date: Date(), bpm: bpm, hrv: hrv, spo2: spo2)
        entries.insert(newEntry, at: 0) // Newest on top
    }

    private func save() {
        if let encoded = try? JSONEncoder().encode(entries) {
            UserDefaults.standard.set(encoded, forKey: "measurementHistory")
        }
    }

    private func load() {
        if let data = UserDefaults.standard.data(forKey: "measurementHistory"),
           let decoded = try? JSONDecoder().decode([MeasurementEntry].self, from: data) {
            entries = decoded
        }
    }
}
import SwiftUI

struct History: View {
    @EnvironmentObject var historyModel: HistoryModel

    var body: some View {
        GeometryReader { geometry in
            NavigationStack {
                VStack {
                    if historyModel.entries.isEmpty {
                        Spacer()
                        Text("まだ記録がありません")
                            .font(.headline)
                            .foregroundColor(.gray)
                            .padding()
                        Spacer()
                    } else {
                        VStack {
                            List(historyModel.entries.reversed()) { entry in
                                VStack(alignment: .leading, spacing: 6) {
                                    Text(entry.date.formatted(date: .abbreviated, time: .shortened))
                                        .font(.caption)
                                        .foregroundColor(.gray)
                                    
                                    HStack {
                                        Text("💓 BPM: \(entry.bpm)")
                                        Spacer()
                                        Text("🌀 HRV: \(String(format: "%.2f", entry.hrv))")
                                        Spacer()
                                        Text("🌬 SpO₂: \(entry.spo2)%")
                                    }
                                    .font(.body)
                                }
                                .padding(.vertical, 6)
                            }
                            .listStyle(.insetGrouped)
                        }
                        
                    }
                }
                
                .frame(width: geometry.size.width, height: geometry.size.height)
                .background(Color(red: 250/255, green: 246/255, blue: 235/255))
            }.navigationTitle("履歴")
        }
    }
}


#Preview {
    History()
        .environmentObject(HistoryModel())
}
